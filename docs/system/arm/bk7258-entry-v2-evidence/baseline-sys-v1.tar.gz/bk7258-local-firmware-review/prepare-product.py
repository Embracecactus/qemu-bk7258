import hashlib,json,struct,zipfile
from pathlib import Path
p=Path(__file__).resolve().parent
h=lambda b:hashlib.sha256(b).hexdigest()
root=p/'input/firmware';release=json.loads((root/'release.json').read_text())
build=json.loads((root/'evidence/build-manifest.json').read_text())
package=root/release['package']['path'];assert h(package.read_bytes())==release['package']['sha256']
with zipfile.ZipFile(package) as z:
 m=json.loads(z.read('manifest.json'));size=m['layout']['flash_size'];nor=bytearray(b'\xff'*size);ranges=[];items=[]
 for item in m['images']+[m['full_update']]:
  data=z.read(item['member']);a=item['offset'];b=a+len(data)
  assert len(data)==item['size'] and h(data)==item['sha256']
  part=next(x for x in m['layout']['partitions'] if x['name']==item['partition'])
  assert part['offset']<=a<b<=part['offset']+part['size']<=size
  assert all(b<=x or a>=y for x,y in ranges)
  ranges.append((a,b));nor[a:b]=data;items.append(item)
  if item.get('artifact') in ('cp','boot'):
   raw=b''.join(data[i:i+32] for i in range(0,len(data)-33,34))
   (p/(item['artifact']+'-unframed-analysis.bin')).write_bytes(raw)
   if item['artifact']=='cp':
    assert h(raw[512:512+build['inputs']['cp']['size']])==build['inputs']['cp']['sha256']
    print('cp vector', [hex(x) for x in struct.unpack_from('<2I',raw,512)])
   else:
    assert h(raw[:build['inputs']['boot']['size']])==build['inputs']['boot']['sha256']
    print('boot vector', [hex(x) for x in struct.unpack_from('<2I',raw)])
(p/'product.nor').write_bytes(nor)
(p/'input-identity.json').write_text(json.dumps({'source_commit':build['provenance']['source_commit'],'package_sha256':h(package.read_bytes()),'nor_sha256':h(nor),'copied_members':items,'entries':{'bl1':'0x02000000','cp':'0x02010200'},'scope':'Simulation container, byte-identical package members; unspecified ranges erased. Not a physical flash image; no ROM or signature acceptance claim.'},indent=2)+'\n')
print('NOR',h(nor))
