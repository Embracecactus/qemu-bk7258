Local unchanged-firmware evidence, 24 before/after captures.
Source package remains in readonly-copy.json locations. No firmware payloads or private device backups included.
Copy the three verified local source files into input/firmware using their relative release paths, then run prepare-product.py to recreate product.nor. The probe doc gives commands; create input.status as bytes([0,0,0x20])+bytes(509).
First fault and later stopped CPU state are separate; no complete boot success asserted.
